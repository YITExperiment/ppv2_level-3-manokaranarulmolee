import turtle
turtle.speed('fast')
turtle.pensize(4)
tp = turtle.Turtle()
radius = 20
i=1
COL=iter(['red','orange','yellow','green','blue','purple'])
while i <= 6:
  i=i+1
  tp.color(next(COL))
  radius=radius+10
  tp.circle(radius)


